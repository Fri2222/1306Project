#include "ti_msp_dl_config.h"
#include "oled_spi.h"

#define CLK_HZ 32e+06 // 系统时钟
#define ADC_SAMPLE_SIZE (4) //ADC转换数组大小

volatile bool ADC_Flag, ADC_Error_Flag;
volatile uint16_t ADC_Val[ADC_SAMPLE_SIZE];
uint16_t PWM_0;

int main(void) {
    SYSCFG_DL_init();

    DL_Timer_startCounter(PWM_0_INST);
    DL_Timer_startCounter(PWM_1_INST);

	//配置DMA源地址，参数1DMA指针，参数2DMA通道，参数3DMA源地址
	DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID,(uint32_t) DL_ADC12_getFIFOAddress(ADC12_0_INST));
	//配置DMA目的地址
	DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t) &ADC_Val[0]);
	
    // 开启ADC中断
    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
	
	
    OLED_Init(); // 初始化OLED  
    OLED_Clear();

    while (1) {
        ADC_Flag = false;
		ADC_Error_Flag =false;
		 
		//设置DMA传输大小、启用DMA通道、启用ADC DMA和启动ADC转换		
		DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_SAMPLE_SIZE);
        DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
        DL_ADC12_enableDMA(ADC12_0_INST);
        DL_ADC12_startConversion(ADC12_0_INST);
		
		if (DL_ADC12_STATUS_CONVERSION_ACTIVE ==DL_ADC12_getStatus(ADC12_0_INST)) {
			DL_ADC12_stopConversion(ADC12_0_INST);
		}
		
        // 等待ADC转换完成
        while (ADC_Flag == false);

        // 读取ADC结果
		ADC_Val[0] = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);
        //显示ADC结果
		OLED_ShowString(50,0,":ADC_Val");
        OLED_ShowNum(0, 0, ADC_Val[0], 4, 18);
        OLED_ShowNum(0, 2, ADC_Val[1], 4, 18);
		
		OLED_ShowString(50,6,"PWM1:");
        PWM_0 = DL_TimerG_getCaptureCompareValue(PWM_0_INST, DL_TIMER_CC_0_INDEX);
        OLED_ShowNum(90, 6, PWM_0, 4, 18);
	
		DL_ADC12_disableConversions(ADC12_0_INST);
        DL_ADC12_enableConversions(ADC12_0_INST);
    }
}

void ADC12_0_INST_IRQHandler(void) {
    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)) {
    case DL_ADC12_IIDX_DMA_DONE:
        ADC_Flag = true;
        break;
    case DL_ADC12_IIDX_UNDERFLOW:
        ADC_Error_Flag = true;
        break;
    default:
        break;
}
}
