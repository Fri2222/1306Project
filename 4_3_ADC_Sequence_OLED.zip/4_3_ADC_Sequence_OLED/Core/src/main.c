#include "ti_msp_dl_config.h"
#include "oled_spi.h"

#define CLK_HZ 32e+06 // 系统时钟

volatile bool ADC_Flag;
volatile uint16_t ADC_Val_0;
volatile uint16_t ADC_Val_1;
uint16_t PWM_0;

int main(void) {
    SYSCFG_DL_init();

    DL_Timer_startCounter(PWM_0_INST);
    DL_Timer_startCounter(PWM_1_INST);

    // 开启ADC中断
    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);

    OLED_Init(); // 初始化OLED  
    OLED_Clear();

    while (1) {
        ADC_Flag = false;

        // 开始ADC转换
        DL_ADC12_enableConversions(ADC12_0_INST);
        DL_ADC12_startConversion(ADC12_0_INST);

        // 等待ADC转换完成
        while (ADC_Flag == false);

        // 读取ADC结果
        ADC_Val_0 = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0); // 读取memory0
        ADC_Val_1 = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_1); // 读取memory1

        // 显示ADC结果
        OLED_ShowNum(0, 0, ADC_Val_0, 4, 18);
        OLED_ShowNum(0, 2, ADC_Val_1, 4, 18);

        // 显示日期和时间
        OLED_ShowString(2, 4, "2024.1.15");

        // 读取和显示PWM值
        PWM_0 = DL_TimerG_getCaptureCompareValue(PWM_0_INST, DL_TIMER_CC_0_INDEX);
        OLED_ShowNum(3, 6, PWM_0, 4, 18);
    }
}

void ADC12_0_INST_IRQHandler(void) {
    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)) {
        case DL_ADC12_IIDX_MEM1_RESULT_LOADED:
            ADC_Flag = true;
            break;
        default:
            break;
    }
}
