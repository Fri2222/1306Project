/* syscfg配置为低频时钟LFCLK或者中频时钟
*  波特率为9600
*  字长为8位
* 使能接受中断Interrupt Configuration
*  DMA不用配置
* RE A11/15     TX A10/14
 */
#include "ti_msp_dl_config.h"

#define CLK_HZ 32e+06 // 系统时钟

volatile bool ADC_Flag;
volatile uint16_t ADC_Val;

void delay_ms(int x);

int main(void)
{
	SYSCFG_DL_init();
	
    ADC_Flag = false;
	
	//清除中断
	NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);
	//使能中断
	NVIC_EnableIRQ(UART_0_INST_INT_IRQN);

	NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
	
	while (false == ADC_Flag)
		
	while (1) {
		delay_ms(1000);

		DL_ADC12_startConversion(ADC12_0_INST);
        
		ADC_Val = DL_ADC12_getMemResult(ADC12_0_INST, DL_ADC12_MEM_IDX_0);
        uint8_t lowbyte  = (uint8_t)(ADC_Val & 0xFF);
        uint8_t highbyte = (uint8_t)((ADC_Val >> 8) & 0xFF);
        DL_UART_Main_transmitData(UART_0_INST, highbyte);
        DL_UART_Main_transmitData(UART_0_INST, lowbyte);

        ADC_Flag = false;
        DL_ADC12_enableConversions(ADC12_0_INST);
	}
  }

void UART1_IRQHandler(void)

{
  if(DL_UART_getEnabledInterruptStatus(UART1,DL_UART_INTERRUPT_RX) == DL_UART_INTERRUPT_RX)

  {

	  volatile char c;

	  c = DL_UART_receiveData(UART1);//接收数据

	  DL_UART_transmitData(UART1, c);//发送数据

	  DL_UART_clearInterruptStatus(UART1,DL_UART_INTERRUPT_RX);//清除中断标志位

  }

}
void delay_ms(int x)
{
  delay_cycles(CLK_HZ / 1000 * x);
}

void ADC12_0_INST_IRQHandler(void)
{
    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)) {
        case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
            ADC_Flag = true;
            break;
        default:
            break;
    }
}
