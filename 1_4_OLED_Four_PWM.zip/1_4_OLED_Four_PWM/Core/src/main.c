#include "ti_msp_dl_config.h"

#include "oled_spi.h"

#define CLK_HZ 32e+06 // 系统时钟
uint16_t PWM_0;
int main(void)
{
    SYSCFG_DL_init();

    DL_Timer_startCounter(PWM_0_INST);
	DL_Timer_startCounter(PWM_1_INST);
	
	
	OLED_Init();			//初始化OLED  
	//delay_ms(100000);this expression may be wrong! the sysclk doesn't recognize this function in right way!
	//delay_cycles(120000000);
	OLED_Clear();
	
	while (1) {
//     if (!DL_GPIO_readPins(GPIO_KEY_PORT, GPIO_KEY_KEY_0_PIN)) // 外界改变后经过10ms延迟，判断此时是否按下
//     {
//		DL_GPIO_togglePins(GPIO_LED_PORT, GPIO_LED_LED_0_PIN); // 翻转LED
//		delay_ms(300);                              // 300ms延迟，防止按下一次按键却被认为按下了多次按键，导致LED多次翻转
//	
//	
//		uint16_t PWM_0 = DL_TimerG_getCaptureCompareValue(PWM_0_INST, DL_TIMER_CC_0_INDEX);

		OLED_ShowCHinese(0,0,3);//
		OLED_ShowCHinese(18,0,4);//
		OLED_ShowNum(0,2,100,3,18);
		OLED_ShowString(1,4,"2024.1.15");
		 PWM_0= DL_TimerG_getCaptureCompareValue(PWM_0_INST,DL_TIMER_CC_0_INDEX);
		OLED_ShowNum(0,6,PWM_0,4,18);
		//DL_TimerG_setCaptureCompareValue(PWM_0_INST, 0, DL_TIMERG_CAPTURE_COMPARE_0_INDEX);

//	 }

    }
}
