#include "ti_msp_dl_config.h"
#include "oled_spi.h"

#define CLK_HZ 32e+06 // 系统时钟
#define ADC_SAMPLE_SIZE (64) //ADC转换数组大小

/* When FIFO is enabled 2 samples are compacted in a single word */
#define ADC_FIFO_SAMPLES (ADC_SAMPLE_SIZE / 2)

uint16_t gADCSamplesPing[ADC_SAMPLE_SIZE];
uint16_t gADCSamplesPong[ADC_SAMPLE_SIZE];

volatile bool gPing;
volatile bool ADC_Flag, ADC_Error_Flag;
uint16_t PWM_0;

int main(void) {
    SYSCFG_DL_init();
	
    DL_Timer_startCounter(PWM_0_INST);
    DL_Timer_startCounter(PWM_1_INST);
	
	gPing = true;
	//配置DMA源地址，参数1DMA指针，参数2DMA通道，参数3DMA源地址
	//配置DMA目的地址
  /* Configure DMA source, destination and size */
  DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)DL_ADC12_getFIFOAddress(ADC12_0_INST));
  DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)&gADCSamplesPing[0]);
  DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_FIFO_SAMPLES);
  DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
    // 开启ADC中断
    NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
	
	
    OLED_Init(); // 初始化OLED  
    OLED_Clear();
	

	DL_ADC12_startConversion(ADC12_0_INST);
    while (1) {
		
		ADC_Flag = false;
		ADC_Error_Flag =false;
        
		// 等待ADC转换完成
		while (ADC_Flag == false)   
			
		/* Switch to send ADC Results to Pong Buffer */
		if (gPing) {
		//设置DMA传输大小、启用DMA通道、启用ADC DMA和启动ADC转换		
			  DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)&gADCSamplesPong[0]);
			  DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_FIFO_SAMPLES);
			  DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
			  DL_ADC12_enableDMA(ADC12_0_INST);
				
			  gPing = false;
			}
		else {

			  DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)&gADCSamplesPing[0]);
			  DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, ADC_FIFO_SAMPLES);
			  DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
			  DL_ADC12_enableDMA(ADC12_0_INST);

			  gPing = true;
		}	



        //显示ADC结果
		OLED_ShowString(50,0,":ADC_Val");
        OLED_ShowNum(0, 0, gADCSamplesPing[0], 4, 18);
        OLED_ShowNum(0, 2, gADCSamplesPing[1], 4, 18);
		OLED_ShowNum(0, 4, gADCSamplesPong[2], 4, 18);
        OLED_ShowNum(0, 6, gADCSamplesPong[3], 4, 18);
		
		OLED_ShowString(50,6,"PWM1:");
        PWM_0 = DL_TimerG_getCaptureCompareValue(PWM_0_INST, DL_TIMER_CC_0_INDEX);
        OLED_ShowNum(90, 6, PWM_0, 4, 18);
	
		DL_ADC12_disableConversions(ADC12_0_INST);
        DL_ADC12_enableConversions(ADC12_0_INST);
    }
}

void ADC12_0_INST_IRQHandler(void) {
    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)) {
    case DL_ADC12_IIDX_DMA_DONE:
        ADC_Flag = true;
        break;
    case DL_ADC12_IIDX_UNDERFLOW:
        ADC_Error_Flag = true;
        break;
    default:
        break;
}
}
