#include "ti_msp_dl_config.h"
#define CLK_HZ 32e+06 // 系统时钟
int main(void)
{
    SYSCFG_DL_init();

    DL_TimerG_startCounter(PWM_0_INST);
	

	while (1) {

    }
}
void delay_ms(int x)
{
  delay_cycles(CLK_HZ / 1000 * x);
}
