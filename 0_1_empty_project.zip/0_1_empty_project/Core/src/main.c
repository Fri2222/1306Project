#include "ti_msp_dl_config.h"

int main(void)
{
    SYSCFG_DL_init();
    while(1)
		{
			if(DL_GPIO_readPins(Demo_PORT,Demo_LED_PIN) == 0)//�ж�IO��ƽ
        {
            DL_GPIO_clearPins(Demo_PORT,Demo_LED_PIN);//����LED
    
        }
        else
            DL_GPIO_setPins(Demo_PORT,Demo_LED_PIN);//Ϩ��LED

    }
}