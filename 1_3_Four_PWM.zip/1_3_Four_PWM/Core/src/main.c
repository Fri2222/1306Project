#include "ti_msp_dl_config.h"
#define CLK_HZ 32e+06 // 系统时钟
void delay_ms(int x);
uint16_t Key_State;
int main(void)
{
    SYSCFG_DL_init();

    DL_Timer_startCounter(PWM_0_INST);
	DL_Timer_startCounter(PWM_1_INST);
	while (1) {
//     if (!DL_GPIO_readPins(GPIO_KEY_PORT, GPIO_KEY_KEY_0_PIN)) // 外界改变后经过10ms延迟，判断此时是否按下
//     {
//		DL_GPIO_togglePins(GPIO_LED_PORT, GPIO_LED_LED_0_PIN); // 翻转LED
//		delay_ms(300);                              // 300ms延迟，防止按下一次按键却被认为按下了多次按键，导致LED多次翻转
//	
//		 
//		//DL_TimerG_setCaptureCompareValue(PWM_0_INST, 0, DL_TIMERG_CAPTURE_COMPARE_0_INDEX);
//	 }

    }
}
void delay_ms(int x)
{
  delay_cycles(CLK_HZ / 1000 * x);
}
